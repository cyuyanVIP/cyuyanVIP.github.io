#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H

#include <QWidget>
#include <QLabel>
#include "boardwidget.h"

class GameWidget : public QWidget
{
    Q_OBJECT

public:
    GameWidget(QWidget *parent = 0);
    ~GameWidget();

private:
    void showWinner(int winner);

    void switchNextPlayer(int player);

private:
    BoardWidget *boardWidget;
    QLabel *playerLabel;
};

#endif // GAMEWIDGET_H
