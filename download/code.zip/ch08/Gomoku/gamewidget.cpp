#include "gamewidget.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QPushButton>
#include <QString>

GameWidget::GameWidget(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("五子棋");

    QHBoxLayout * mainLayout = new QHBoxLayout(this);
    QVBoxLayout *vLayout = new QVBoxLayout();
    boardWidget = new BoardWidget(this);

    QHBoxLayout *hLayout = new QHBoxLayout();
    QPushButton *newGame = new QPushButton("重新开始");
    playerLabel = new QLabel("轮到黑方落子", this);
    playerLabel->setFont(QFont("微软雅黑", 15));
    hLayout->addWidget(newGame);
    hLayout->addStretch();

    vLayout->addWidget(playerLabel);
    vLayout->addStretch();
    vLayout->addLayout(hLayout);

    mainLayout->addWidget(boardWidget);
    mainLayout->addLayout(vLayout);

    connect(newGame, &QPushButton::clicked, boardWidget, &BoardWidget::initBoard);
    connect(boardWidget, &BoardWidget::gameOver, this, &GameWidget::showWinner);
    connect(boardWidget, &BoardWidget::switchNextPlayer, this, &GameWidget::switchNextPlayer);
}

void GameWidget::switchNextPlayer(int player)
{
    QString playerName = (player == BoardWidget::WHITE_PLAYER) ? "白方" : "黑方";
    QString labelText = tr("轮到%1落子").arg(playerName);
    playerLabel->setText(labelText);
    
}

GameWidget::~GameWidget()
{

}

void GameWidget::showWinner(int winner)
{
    if (winner != 2)
    {
        QString playerName = (winner == BoardWidget::WHITE_PLAYER) ? "白方" : "黑方";
        QMessageBox::information(this, "游戏结束", tr("恭喜%1获胜！！").arg(playerName), QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(this, "游戏结束", "和棋！", QMessageBox::Ok);
    }
}
