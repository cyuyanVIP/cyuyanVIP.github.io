#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setMouseTracking(true);//将鼠标轨迹跟踪开启，否则鼠标移动事件只会在鼠标按钮被按下时才产生。
}

Widget::~Widget()
{
    delete ui;
}

//按下鼠标
void Widget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        ui->motionLabel->setText("left button press");
    }
    else
    {
        ui->motionLabel->setText("right button press");
    }
}

//松开鼠标
void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        ui->motionLabel->setText("left button release");
    }
    else
    {
        ui->motionLabel->setText("right button release");
    }
}

//双击鼠标
void Widget::mouseDoubleClickEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        ui->motionLabel->setText("left button double click");
    }
    else
    {
        ui->motionLabel->setText("right button double click");
    }
}

//在鼠标移动的时候，将鼠标的坐标显示。
void Widget::mouseMoveEvent(QMouseEvent *event)
{
    QPoint pos = event->globalPos();
    ui->postLabel->setText(QString("(%1,%2)").arg(pos.rx()).arg(pos.ry()));
}

//在鼠标滚轮滚动的时候，将鼠标滚动的信息显示出来。
void Widget::wheelEvent(QWheelEvent *event)
{
    if (event->delta() > 0)
    {
        ui->motionLabel->setText("wheel up roll");
    }
    else
    {
        ui->motionLabel->setText("wheel down roll");
    }
}
